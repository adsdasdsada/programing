$(function(){
    //alert($('h1').text());
    //alert($('.link-moto').text());
    //$('.slide-btn').hide();
    //$('.features-grid').hide(3000);
    //$('.categorie').show(2000);
    //alert($('.top-nav li').text());
    //$('.t').hide(3500);
    //$('.t').show(2000);
    //$('h3>span').hide(1000);
    //$('h3>span').show(2000);
    alert($('.blog-post-info span a').text());
})
